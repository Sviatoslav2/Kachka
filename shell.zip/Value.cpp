//
// Created by Admin on 31.05.2018.
//

#include <boost/algorithm/string.hpp>
#include <map>
#include "File.h"


std::string ModString(std::string Vlue,std::string Simbol){
    const char *cstrV = Vlue.c_str();
    const char *cstrS = Simbol.c_str();
    std::string Res;
    for(auto& a:Vlue){
        if(a != cstrS[0]){
            Res+=a;
        }
    }
    return Res;
}

std::map<std::string, std::string> MapOfValue(std::vector<std::string>& Data,std::map<std::string, std::string>& Map){
    for(int i = 0; i < Data.size(); ++i){
        if((Data[i] == std::string("=")) && i > 0 && i < Data.size()){// Var = Value
            Map[std::string("$")+Data[i-1]] = Data[i+1];
        }
        else if(IsSimbolInString(Data[i],std::string("="))&& i + 1 < Data.size()){ // Var= Value
            auto Key = ModString(Data[i],std::string("="));
            Map[std::string("$")+Key] = Data[i+1];
        }

    }
    return Map;
};

bool IsElem(std::vector<std::string>Data){
    bool key = false;
    for(int i = 0; i < Data.size(); ++i){
        if(Data[i] == std::string("=")){
            key = true;
        }
    }
    return key;
}

std::vector<std::string>DataMapVector(std::vector<std::string>Data, std::map<std::string, std::string>& Map){
    for(int i = 0; i < Data.size(); ++i){
        if(IsSimbolInString(Data[i],std::string("$"))){
            Data[i] = Map[Data[i]];
        }
    }
    return Data;
}

