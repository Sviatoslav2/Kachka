#include <iostream>

//#include "Queue.h"
#include <deque>
#include <mutex>
#include <condition_variable>
#include <deque>
#include <vector>
#include <thread>

template<class T>
class Stack{
private:
    std::deque<T> deque_;
    std::recursive_mutex mux_;
    std::condition_variable_any cond_var_;
public:
    void push(T elem){
        std::unique_lock<std::recursive_mutex> lck(mux_);
        deque_.push_back(elem);
        cond_var_.notify_one();
    }

    size_t size(){
        std::unique_lock<std::recursive_mutex> lck(mux_);
        return deque_.size();
    }

    bool empty(){
        std::unique_lock<std::recursive_mutex> lck(mux_);
        return size() == 0;
    }

    T pop(){
        std::unique_lock<std::recursive_mutex> lck(mux_);
        while(empty())
            cond_var_.wait(lck);
        auto res = deque_.back();
        deque_.pop_back();
        return res;
    }
};
int twice(int m) {
    return 2 * m;
}

void Counting(Stack<int> &stack,long l1,long l2){

    for(size_t i = l1; i < l2; ++i){
        stack.push(i);
    }
}

int main() {
    Stack<int> stack;
    std::vector<std::thread> threads;
    int Nthreads = 5;
    int length = 1000;
    for(size_t i = 0; i < Nthreads; ++i){
        threads.push_back(std::thread(Counting,std::ref(stack),i*length, i*length -1));
    }
    for(auto& a: threads){
        a.join();
    }
    //std::cout<<stack.pop()<<std::endl;
    return 0;
}