//
// Created by Admin on 31.05.2018.
//

#ifndef MYSELL_FILE_H
#define MYSELL_FILE_H
#include <boost/filesystem.hpp>
#include <map>
namespace fs1 = boost::filesystem;
bool IsSimbolInString(std::string String, std::string symbol);
std::vector<std::string> VectorWithoutElementsWithSimbol(std::vector<std::string> Vector , std::string Simol);
std::vector<std::string> Split(std::string line);
std::vector<std::vector<std::string>> ReadVectorOfLine(std::istream& file,std::map<std::string, std::string>& Map);
std::vector<std::vector<std::string>> FileLins(std::string NameOfFile,std::map<std::string, std::string>& Map);
int FileDoing(std::string NameOfFile,bool ExitKey,std::string MainDirectory,std::string Simbol,std::map<std::string, std::string>& Map,std::map<std::string, std::string>& MapComand);
int File(std::string Name,int ERROR, bool ExitKey, std::string MainDirectory,std::map<std::string, std::string>& Map,std::map<std::string, std::string>& MapComand);
fs1::path FileFinder(std::string Name);
#endif //MYSELL_FILE_H
