//
// Created by Admin on 31.05.2018.
//

#ifndef MYSELL_FILE_H
#define MYSELL_FILE_H
bool IsSimbolInString(std::string String, std::string symbol);
std::vector<std::string> VectorWithoutElementsWithSimbol(std::vector<std::string> Vector , std::string Simol);
std::vector<std::string> Split(std::string line);
std::vector<std::vector<std::string>> ReadVectorOfLine(std::istream& file);
std::vector<std::vector<std::string>> FileLins(std::string NameOfFile);
int FileDoing(std::string NameOfFile,bool ExitKey,std::string MainDirectory,std::string Simbol);
int File(std::string Name,int ERROR, bool ExitKey, std::string MainDirectory);
#endif //MYSELL_FILE_H
