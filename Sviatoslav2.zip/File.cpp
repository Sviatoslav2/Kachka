//
// Created by Admin on 31.05.2018.
//
#include "Myshell.h"
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <boost/algorithm/string.hpp>
#include <iostream>
#include <fstream>

namespace fs1 = boost::filesystem;
namespace fs2 = boost;

bool IsSimbolInString(std::string String, std::string symbol){
    int k = String.find(symbol);
    return k < String.size();
}

std::vector<std::string> VectorWithoutElementsWithSimbol(std::vector<std::string> Vector , std::string Simol){
    std::vector<std::string>Res;
    bool key = true;
    for(auto& a: Vector){
        if(key&&(not IsSimbolInString(a,Simol))){
            Res.emplace_back(a);
        }
        else{
            key = false;
        }
    }
    return Res;
}

std::vector<std::string> Split(std::string line){
    std::vector<std::string> words;
    std::string s_copy = fs2::trim_copy(line);
    fs2::split(words, s_copy, fs2::is_any_of(" "), fs2::token_compress_on);
    return words;
}

std::vector<std::vector<std::string>> ReadVectorOfLine(std::istream& file) {
    std::vector <std::vector<std::string>> res;
    std::string line;
    while (getline(file, line)) {
        auto lineOfWords = Split(line);
        res.emplace_back(lineOfWords);
    }
    return res;
}

std::vector<std::vector<std::string>> FileLins(std::string NameOfFile){
    std::cerr << NameOfFile<< std::endl;
    std::ifstream read_file(NameOfFile);
    if(!read_file.is_open())
    { std::cerr << "Error opening file "<< std::endl;
        exit(1);
    }
    auto VectorOfLine = ReadVectorOfLine(read_file);// string::npos
    return VectorOfLine;
}



int FileDoing(std::string NameOfFile,bool ExitKey,std::string MainDirectory,std::string Simbol){

    auto Lines = FileLins(NameOfFile);//VectorWithoutElementsWithSimbol(VectorOfLine,Simbol);

    int ERROR = 0;
    for(auto& a: Lines){
        if(a[0] != std::string("#")){
            auto b = VectorWithoutElementsWithSimbol(a,Simbol);

            ERROR = Consol(ExitKey,MainDirectory,ERROR,b);

        }
    }
    return ERROR;
}



int File(std::string Name,int ERROR, bool ExitKey, std::string MainDirectory){
    fs1::path PathToFile = Name;
    fs1::path Path;
    if (PathToFile.parent_path().empty()) {
        Path = get_current_directory() + "/" + PathToFile.filename().string();
    } else {
        Path = PathToFile;
    }
    if (fs1::is_regular_file(Path)) {
        changeDirectory(Path.parent_path().string());
        ERROR = FileDoing(Path.filename().string(), ExitKey, MainDirectory,std::string("#"));
    }
    return ERROR;
}

