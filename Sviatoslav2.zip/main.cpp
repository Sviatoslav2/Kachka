#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <cstring>
#include <cmath>
#include <cmath>
#include <sstream>
#include <unistd.h>
#include <string>
#include <limits.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <boost/lexical_cast.hpp>
#include <boost/filesystem.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <boost/algorithm/string.hpp>
#include "Myshell.h"
#include "File.h"
namespace fs1 = boost::filesystem;
namespace fs2 = boost;



int main(int argc, char *argv[]) {
    bool FileCon = false;
    bool ExitKey = true;
    int ERROR = 0;
    int NumberMexitMcdMerrnoMpwd = 0;
    bool MexitKey = false;
    std::string MainDirectory = get_current_directory();
    std::vector<std::string> Vector;
    std::vector<std::string> VectorOfFile;
    for(int i = 1; i < argc;++i){
        Vector.emplace_back(argv[i]);
    }
    if(Vector.size() == 1) {
        ERROR = File(Vector[0],ERROR,ExitKey, MainDirectory);
    }//bool FileCon




    while (ExitKey) {
        std::cout <<"#"<< get_current_directory() + " $";
        auto dataFromConsol = split_cmd_line(std::cin);
        if(dataFromConsol.size() != 0){
            NumberMexitMcdMerrnoMpwd = HelpRice(dataFromConsol);
            if(NumberMexitMcdMerrnoMpwd == 6 && dataFromConsol.size() == 2){

                ERROR = File(dataFromConsol[1],ERROR,ExitKey, MainDirectory);
            }
            else{
                ERROR = Consol(ExitKey,MainDirectory,ERROR,dataFromConsol);
            }

        }
    }
}